#ifndef UTILIDADES_H
#define UTILIDADES_H

#include <iostream>

using namespace std;

void imprimirArray(double* secuencia, int util);

void eliminarRepetidos(double* array, int &util);

void ordenarArray(double* array, int util);

int mezclarUnico(double* array1,int util1,double* array2, int util2, double* array3);

#endif 
