
#ifndef UTILIDADES_H
#define UTILIDADES_H

#include <iostream>

using namespace std;

void imprimir(int *secuencia, int util);
void imprimir(int **secuencia, int util);
void ordenarPunteros(int *array, int **parray, int util);

#endif //EJERCICIO1_UTILIDADES_H
